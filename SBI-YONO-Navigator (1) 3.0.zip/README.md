# 🏦 SBI YONO Navigator

## Autonomous Digital Adoption AI for SBI Hackathon @ GFF 2026

**Problem Statement:** Digital Adoption - Build contextual and adaptive AI experiences that encourage adoption of digital banking services.

**Solution:** Multi-agent AI system that predicts customer needs 48 hours before they know it, and autonomously completes digital adoption with one-tap consent.

---

## 🎯 3 Demo Scenarios

| # | Scenario | Customer | Trigger | AI Action |
|---|----------|----------|---------|-----------|
| 1 | QR Cash Withdrawal | Ramesh (Hindi) | Near ATM + cash pattern | Pre-generates QR, one tap to withdraw |
| 2 | Auto-Invest | Priya (Tamil) | Salary credited + no SIP | Pre-fills SIP form, one tap to start |
| 3 | Insurance | Rajesh (Telugu) | Hospital payment detected | Opens Sukanya Samriddhi, one tap to complete |

---

## 🏗️ Architecture (5 AI Agents)

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   PROPHET   │───→│  STRATEGIST │───→│  EXECUTOR   │
│  (Predict)  │    │   (Plan)    │    │   (Act)     │
└─────────────┘    └─────────────┘    └─────────────┘
                                              │
                                              ↓
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   BHASHA    │←───│   GUARDIAN  │←───│  (Validate) │
│  (Speak)    │    │  (Secure)   │    └─────────────┘
└─────────────┘    └─────────────┘
```

---

## 🚀 Quick Start (Zero Cost)

### Step 1: Backend (Python)

```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate

pip install -r requirements.txt
python main.py
```

Backend runs at: `http://localhost:8000`

### Step 2: Frontend (Flutter)

```bash
cd frontend/sbi_navigator

# Install Flutter dependencies
flutter pub get

# Run on emulator or browser
flutter run
```

### Step 3: Test API

```bash
# Get demo scenarios
curl http://localhost:8000/api/demo/scenarios

# Trigger prediction for Ramesh (QR Cash)
curl -X POST http://localhost:8000/api/predict   -H "Content-Type: application/json"   -d '{"customer_id": "CUST001", "current_location": "near_SBI_ATM"}'

# Trigger prediction for Priya (SIP)
curl -X POST http://localhost:8000/api/predict   -H "Content-Type: application/json"   -d '{"customer_id": "CUST002"}'

# Trigger prediction for Rajesh (Insurance)
curl -X POST http://localhost:8000/api/predict   -H "Content-Type: application/json"   -d '{"customer_id": "CUST003"}'

# Approve action
curl -X POST http://localhost:8000/api/consent   -H "Content-Type: application/json"   -d '{"task_id": "YOUR_TASK_ID", "customer_id": "CUST001", "approved": true}'
```

---

## 📁 Project Structure

```
sbi-navigator/
├── backend/
│   ├── main.py              # FastAPI server
│   ├── requirements.txt     # Python dependencies
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── prophet.py       # Predicts customer needs
│   │   ├── strategist.py    # Creates engagement plan
│   │   ├── executor.py      # Pre-fills and completes tasks
│   │   ├── guardian.py      # Security & compliance
│   │   └── bhasha.py        # Vernacular voice (22 languages)
│   └── data/
│       └── mock_customers.json
├── frontend/
│   └── sbi_navigator/
│       ├── lib/
│       │   └── main.dart    # Flutter app
│       └── pubspec.yaml
└── README.md
```

---

## 💰 Business Impact (For Pitch)

- **43 Crore** SBI customers not using digital banking
- **₹40-60** saved per transaction shifted from branch to digital
- **10% adoption lift** = **₹400+ Crore annual savings** for SBI
- **500M+** customers can be served with this architecture

---

## 🔒 Security Features

- ✅ KYC verification before every action
- ✅ Fraud pattern detection (Guardian Agent)
- ✅ Explicit consent required (one-tap approval)
- ✅ Immutable audit trail with SHA-256 hashes
- ✅ RBI compliance built-in
- ✅ DPDP Act (India) compliant

---

## 🛠️ Tech Stack (All Free)

| Layer | Tool | Cost |
|-------|------|------|
| Backend | Python + FastAPI | Free |
| Agents | Custom Python classes | Free |
| Frontend | Flutter | Free |
| Voice | Bhashini API (Govt of India) | Free |
| LLM | Groq API (free tier) | Free |
| Hosting | Render/Railway free tier | Free |

**Total Cost: ₹0**

---

## 🎤 Pitch Deck Points

1. **Problem:** 83% of SBI customers are digitally inactive (43 Crore people)
2. **Solution:** AI Digital Twin that predicts needs before customer knows
3. **Demo:** 3 scenarios showing one-tap digital adoption
4. **Architecture:** 5-agent swarm with human-in-the-loop safety
5. **Business:** ₹400Cr+ savings, 25% adoption lift
6. **Scale:** 500M customers, 22 languages, 10,000 TPS
7. **Security:** RBI compliant, DPDP ready, immutable audit
8. **Ask:** Pilot with 1M SBI customers

---

## 🏆 Winning Strategy

- **Build less, polish more** - 3 perfect scenarios > 10 buggy features
- **Demo is everything** - 2-minute live demo makes judges gasp
- **Speak banker language** - ROI, savings, scalability
- **Show AI depth** - Multi-agent orchestration, not just a chatbot

**Built by: Solo Developer + AI Tools = Winning Team**
