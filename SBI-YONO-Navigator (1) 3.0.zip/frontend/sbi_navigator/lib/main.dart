import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

const String API_BASE = "http://localhost:8000";

void main() {
  runApp(const SBIYONONavigator());
}

class SBIYONONavigator extends StatelessWidget {
  const SBIYONONavigator({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SBI YONO Navigator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF0033A0),
        scaffoldBackgroundColor: const Color(0xFF0A0E21),
        cardColor: const Color(0xFF1D1E33),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.white),
          bodyMedium: TextStyle(color: Colors.white70),
        ),
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
    );
  }
}

// ===== SPLASH SCREEN =====
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeIn),
    );
    _scaleAnimation = Tween<double>(begin: 0.5, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
    );
    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const DashboardScreen()),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E21),
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: ScaleTransition(
            scale: _scaleAnimation,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0033A0), Color(0xFF0066CC)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF0033A0).withOpacity(0.5),
                        blurRadius: 30,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.auto_awesome,
                    size: 60,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 30),
                const Text(
                  'SBI YONO',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 2,
                  ),
                ),
                const Text(
                  'NAVIGATOR',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w300,
                    color: Color(0xFF00D4FF),
                    letterSpacing: 4,
                  ),
                ),
                const SizedBox(height: 15),
                const Text(
                  'Autonomous Digital Adoption AI',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white54,
                  ),
                ),
                const SizedBox(height: 50),
                SizedBox(
                  width: 200,
                  child: LinearProgressIndicator(
                    backgroundColor: Colors.white12,
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF00D4FF)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ===== DASHBOARD SCREEN =====
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  String selectedCustomer = "CUST001";
  Map<String, dynamic>? prediction;
  bool isLoading = false;
  int digitalStars = 0;
  double digitalMaturity = 0.25;
  bool showConfetti = false;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  final Map<String, Map<String, dynamic>> customers = {
    "CUST001": {
      "name": "Ramesh Kumar",
      "language": "Hindi",
      "balance": "50,000",
      "maturity": 0.25,
      "stars": 2,
      "color": Colors.orange,
      "avatar": "R",
    },
    "CUST002": {
      "name": "Priya Sharma",
      "language": "Tamil",
      "balance": "75,000",
      "maturity": 0.35,
      "stars": 3,
      "color": Colors.blue,
      "avatar": "P",
    },
    "CUST003": {
      "name": "Rajesh Reddy",
      "language": "Telugu",
      "balance": "1,20,000",
      "maturity": 0.40,
      "stars": 4,
      "color": Colors.green,
      "avatar": "R",
    }
  };

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1, end: 1.1).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> triggerPrediction() async {
    setState(() {
      isLoading = true;
      prediction = null;
      showConfetti = false;
    });

    await Future.delayed(const Duration(seconds: 1)); // Simulate AI thinking

    try {
      final response = await http.post(
        Uri.parse('$API_BASE/api/predict'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "customer_id": selectedCustomer,
          "current_location": selectedCustomer == "CUST001" ? "near_SBI_ATM" : null
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          prediction = jsonDecode(response.body);
          digitalMaturity = prediction!['digital_maturity'] ?? 0.25;
        });
      }
    } catch (e) {
      setState(() {
        prediction = _getMockPrediction();
        digitalMaturity = prediction!['digital_maturity'] ?? 0.25;
      });
    }

    setState(() {
      isLoading = false;
    });
  }

  Map<String, dynamic> _getMockPrediction() {
    final customer = customers[selectedCustomer]!;

    if (selectedCustomer == "CUST001") {
      return {
        "status": "prediction_ready",
        "task_id": "TASK_001",
        "customer": {"name": customer["name"], "language": customer["language"]},
        "prediction": {
          "type": "cash_need",
          "confidence": 0.94,
          "reason": "Customer near ATM, last withdrawal 3 days ago"
        },
        "action": {
          "type": "qr_cash_withdrawal",
          "pre_generated": {
            "qr_code": "SBI_QR_1234",
            "amount_suggested": 10000,
            "atm_location": "SBI ATM - Connaught Place, Delhi"
          },
          "requires_tap": true
        },
        "message": {
          "language": "hindi",
          "message": "Ramesh ji, aap ATM ke paas hain. QR code taiyaar hai. ATM par scan karein, PIN daalein, paise lein. Koi card nahi chahiye."
        },
        "security": {
          "guardian_status": "APPROVED_PENDING_CONSENT",
          "audit_hash": "a1b2c3d4e5f6",
          "checks": {
            "kyc": {"status": "PASS"},
            "fraud": {"status": "PASS"},
            "consent": {"status": "PENDING"}
          }
        },
        "digital_maturity": 0.25
      };
    } else if (selectedCustomer == "CUST002") {
      return {
        "status": "prediction_ready",
        "task_id": "TASK_002",
        "customer": {"name": customer["name"], "language": customer["language"]},
        "prediction": {
          "type": "investment_opportunity",
          "confidence": 0.91,
          "reason": "Salary credited 2 days ago, no SIP found"
        },
        "action": {
          "type": "sip_setup",
          "pre_generated": {
            "fund_name": "SBI Bluechip Fund",
            "sip_amount": 5000,
            "frequency": "monthly",
            "first_installment": "2026-07-05"
          },
          "requires_tap": true
        },
        "message": {
          "language": "tamil",
          "message": "Priya avargale, sambalam vandhu vittadhu. Maadham Rs.5,000 SIP thodangava? Oru tap-il mudindhadhu."
        },
        "security": {
          "guardian_status": "APPROVED_PENDING_CONSENT",
          "audit_hash": "b2c3d4e5f6g7",
          "checks": {
            "kyc": {"status": "PASS"},
            "fraud": {"status": "PASS"},
            "consent": {"status": "PENDING"}
          }
        },
        "digital_maturity": 0.35
      };
    } else {
      return {
        "status": "prediction_ready",
        "task_id": "TASK_003",
        "customer": {"name": customer["name"], "language": customer["language"]},
        "prediction": {
          "type": "life_event_insurance",
          "confidence": 0.88,
          "reason": "Hospital payment 3 days ago - possible childbirth"
        },
        "action": {
          "type": "sukanya_account_open",
          "pre_generated": {
            "scheme": "Sukanya Samriddhi Yojana",
            "initial_deposit": 1000,
            "account_number": "SSY_5678",
            "interest_rate": "8.2%"
          },
          "requires_tap": true
        },
        "message": {
          "language": "telugu",
          "message": "Rajesh gaaru, abhinandanalu! Mi kuthuri kosam Sukanya Samriddhi teravaala? Rs.1000 nundi, 8.2% vaddi."
        },
        "security": {
          "guardian_status": "APPROVED_PENDING_CONSENT",
          "audit_hash": "c3d4e5f6g7h8",
          "checks": {
            "kyc": {"status": "PASS"},
            "fraud": {"status": "PASS"},
            "consent": {"status": "PENDING"}
          }
        },
        "digital_maturity": 0.40
      };
    }
  }

  void _approveAction() {
    setState(() {
      digitalStars += 2;
      digitalMaturity = (digitalMaturity + 0.15).clamp(0.0, 1.0);
      prediction!["action"]["status"] = "COMPLETED";
      showConfetti = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Action Completed!',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(
                    '+2 Digital Stars Earned! Maturity: ${(digitalMaturity * 100).toInt()}%',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final customer = customers[selectedCustomer]!;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0033A0), Color(0xFF0066CC)],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.auto_awesome, size: 20, color: Colors.white),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SBI YONO Navigator',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                Text(
                  'Autonomous Digital Adoption AI',
                  style: TextStyle(fontSize: 10, color: Colors.white70),
                ),
              ],
            ),
          ],
        ),
        backgroundColor: const Color(0xFF0A0E21),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.white70),
            onPressed: () {},
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: CircleAvatar(
              radius: 16,
              backgroundColor: const Color(0xFF0033A0),
              child: const Icon(Icons.person, size: 18, color: Colors.white),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCustomerSelector(),
            const SizedBox(height: 20),
            _buildDigitalTwinCard(customer),
            const SizedBox(height: 20),
            _buildAgentStatus(),
            const SizedBox(height: 20),
            _buildTriggerButton(),
            const SizedBox(height: 20),
            if (isLoading)
              _buildLoadingAnimation()
            else if (prediction != null)
              _buildPredictionCard(),
            if (showConfetti)
              _buildConfetti(),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomerSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1D1E33),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.people, color: Color(0xFF00D4FF), size: 20),
              const SizedBox(width: 8),
              const Text(
                'Select Demo Customer',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: customers.entries.map((entry) {
                final isSelected = selectedCustomer == entry.key;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.only(right: 10),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          selectedCustomer = entry.key;
                          prediction = null;
                          showConfetti = false;
                        });
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: isSelected
                              ? LinearGradient(
                                  colors: [
                                    entry.value["color"] as Color,
                                    (entry.value["color"] as Color).withOpacity(0.7),
                                  ],
                                )
                              : null,
                          color: isSelected ? null : const Color(0xFF0A0E21),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected
                                ? entry.value["color"] as Color
                                : Colors.white24,
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 16,
                              backgroundColor: isSelected ? Colors.white24 : entry.value["color"] as Color,
                              child: Text(
                                entry.value["avatar"] as String,
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  entry.value["name"] as String,
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.white70,
                                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                    fontSize: 13,
                                  ),
                                ),
                                Text(
                                  entry.value["language"] as String,
                                  style: TextStyle(
                                    color: isSelected ? Colors.white70 : Colors.white54,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDigitalTwinCard(Map<String, dynamic> customer) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF0033A0).withOpacity(0.8),
            const Color(0xFF1D1E33),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0033A0).withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      customer["color"] as Color,
                      (customer["color"] as Color).withOpacity(0.7),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: (customer["color"] as Color).withOpacity(0.4),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    customer["avatar"] as String,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      customer["name"] as String,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    Text(
                      '${customer["language"]} | Balance: Rs. ${customer["balance"]}',
                      style: const TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFF00D4FF).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.5)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.circle, color: Color(0xFF00D4FF), size: 8),
                    SizedBox(width: 5),
                    Text(
                      'AI Digital Twin',
                      style: TextStyle(color: Color(0xFF00D4FF), fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.trending_up, color: Color(0xFF00D4FF), size: 14),
                        SizedBox(width: 5),
                        Text('Digital Maturity', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: digitalMaturity,
                        backgroundColor: Colors.white12,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          digitalMaturity < 0.3 ? Colors.orange : digitalMaturity < 0.6 ? const Color(0xFF00D4FF) : Colors.green,
                        ),
                        minHeight: 8,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '${(digitalMaturity * 100).toInt()}% — ${digitalMaturity < 0.3 ? "Digital Beginner" : digitalMaturity < 0.6 ? "Digital Explorer" : "Digital Pro"}',
                      style: TextStyle(
                        color: digitalMaturity < 0.3 ? Colors.orange : digitalMaturity < 0.6 ? const Color(0xFF00D4FF) : Colors.green,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 20),
              Column(
                children: [
                  const Row(
                    children: [
                      Icon(Icons.star, color: Colors.amber, size: 14),
                      SizedBox(width: 5),
                      Text('Digital Stars', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: List.generate(5, (index) {
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.only(right: 2),
                        child: Icon(
                          index < digitalStars ? Icons.star : Icons.star_border,
                          color: index < digitalStars ? Colors.amber : Colors.white24,
                          size: 22,
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAgentStatus() {
    final agents = [
      {"name": "Prophet", "icon": Icons.remove_red_eye, "color": const Color(0xFF9D4EDD), "status": "Active", "desc": "Predict"},
      {"name": "Strategist", "icon": Icons.psychology, "color": const Color(0xFF4361EE), "status": "Active", "desc": "Plan"},
      {"name": "Executor", "icon": Icons.smart_toy, "color": const Color(0xFF06D6A0), "status": "Active", "desc": "Act"},
      {"name": "Guardian", "icon": Icons.shield, "color": const Color(0xFFF72585), "status": "Active", "desc": "Verify"},
      {"name": "Bhasha", "icon": Icons.record_voice_over, "color": const Color(0xFFFF6B6B), "status": "Active", "desc": "Speak"},
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1D1E33),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.memory, color: Color(0xFF00D4FF), size: 20),
              const SizedBox(width: 8),
              const Text(
                'AI Agent Swarm',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green.withOpacity(0.5)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.circle, color: Colors.green, size: 6),
                    SizedBox(width: 4),
                    Text(
                      'All Online',
                      style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: agents.map((agent) {
              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      (agent["color"] as Color).withOpacity(0.2),
                      (agent["color"] as Color).withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: (agent["color"] as Color).withOpacity(0.5)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(agent["icon"] as IconData, color: agent["color"] as Color, size: 18),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          agent["name"] as String,
                          style: TextStyle(color: agent["color"] as Color, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          agent["desc"] as String,
                          style: TextStyle(color: Colors.white54, fontSize: 10),
                        ),
                      ],
                    ),
                    const SizedBox(width: 6),
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: Colors.green, blurRadius: 4, spreadRadius: 1),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTriggerButton() {
    return ScaleTransition(
      scale: _pulseAnimation,
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: isLoading ? null : triggerPrediction,
          icon: isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                )
              : const Icon(Icons.auto_awesome, color: Colors.white),
          label: Text(
            isLoading ? 'AI ANALYZING...' : 'TRIGGER AI PREDICTION',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF0033A0),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 18),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 10,
            shadowColor: const Color(0xFF0033A0).withOpacity(0.5),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingAnimation() {
    return Container(
      padding: const EdgeInsets.all(40),
      child: Column(
        children: [
          const CircularProgressIndicator(
            color: Color(0xFF00D4FF),
            strokeWidth: 3,
          ),
          const SizedBox(height: 20),
          Text(
            'AI Agents Analyzing...',
            style: TextStyle(
              color: const Color(0xFF00D4FF).withOpacity(0.8),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'Prophet → Strategist → Executor → Guardian → Bhasha',
            style: TextStyle(color: Colors.white54, fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildPredictionCard() {
    final pred = prediction!;
    final action = pred["action"] as Map<String, dynamic>;
    final message = pred["message"] as Map<String, dynamic>;
    final security = pred["security"] as Map<String, dynamic>;
    final predictionData = pred["prediction"] as Map<String, dynamic>;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOut,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF1D1E33),
            const Color(0xFF0A0E21),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00D4FF).withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Prediction Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF9D4EDD).withOpacity(0.3),
                      const Color(0xFF9D4EDD).withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFF9D4EDD).withOpacity(0.5)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.remove_red_eye, color: Color(0xFF9D4EDD), size: 14),
                    const SizedBox(width: 6),
                    Text(
                      predictionData["type"].toString().replaceAll('_', ' ').toUpperCase(),
                      style: const TextStyle(color: Color(0xFF9D4EDD), fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Confidence: ${((predictionData["confidence"] as double) * 100).toInt()}%',
                  style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(predictionData["reason"] as String, style: const TextStyle(color: Colors.white70, fontSize: 13)),
          const Divider(color: Colors.white12, height: 25),

          // AI Message
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF0033A0).withOpacity(0.2),
                  const Color(0xFF0033A0).withOpacity(0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF0033A0).withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.record_voice_over, color: Color(0xFFFF6B6B), size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'Bhasha Agent (${message["language"]})',
                      style: const TextStyle(color: Color(0xFFFF6B6B), fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  message["message"] as String,
                  style: const TextStyle(color: Colors.white, fontSize: 15, fontStyle: FontStyle.italic, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Action Details
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF06D6A0).withOpacity(0.1),
                  const Color(0xFF06D6A0).withOpacity(0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF06D6A0).withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.smart_toy, color: Color(0xFF06D6A0), size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'Executor Agent — ${action["type"].toString().replaceAll("_", " ").toUpperCase()}',
                      style: const TextStyle(color: Color(0xFF06D6A0), fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ..._buildActionDetails(action),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Security Badge
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF72585).withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFF72585).withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.shield, color: Color(0xFFF72585), size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Guardian: ${security["guardian_status"]}',
                        style: const TextStyle(color: Color(0xFFF72585), fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Audit: ${security["audit_hash"]}',
                        style: const TextStyle(color: Colors.white54, fontSize: 10),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.verified, color: Colors.green, size: 16),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // One Tap Action Button
          if (action["requires_tap"] == true && action["status"] != "COMPLETED")
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _approveAction,
                icon: const Icon(Icons.touch_app, color: Colors.white),
                label: const Text(
                  'TAP TO COMPLETE',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF06D6A0),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 10,
                  shadowColor: const Color(0xFF06D6A0).withOpacity(0.5),
                ),
              ),
            )
          else if (action["status"] == "COMPLETED")
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.green.withOpacity(0.3),
                    Colors.green.withOpacity(0.1),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.green.withOpacity(0.5)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check_circle, color: Colors.green, size: 28),
                  SizedBox(width: 12),
                  Text(
                    'COMPLETED!',
                    style: TextStyle(color: Colors.green, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _buildActionDetails(Map<String, dynamic> action) {
    final preGen = action["pre_generated"] as Map<String, dynamic>?;
    if (preGen == null) return [];

    return preGen.entries.map((entry) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          children: [
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                color: const Color(0xFF06D6A0),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${entry.key.toString().replaceAll('_', ' ').toUpperCase()}: ',
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
            Text(
              '${entry.value}',
              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      );
    }).toList();
  }

  Widget _buildConfetti() {
    return Container(
      height: 100,
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.celebration, color: Colors.amber.withOpacity(0.8), size: 30),
            const SizedBox(width: 10),
            Icon(Icons.celebration, color: Colors.pink.withOpacity(0.8), size: 25),
            const SizedBox(width: 10),
            Icon(Icons.celebration, color: Colors.green.withOpacity(0.8), size: 30),
            const SizedBox(width: 10),
            Icon(Icons.celebration, color: Colors.blue.withOpacity(0.8), size: 25),
            const SizedBox(width: 10),
            Icon(Icons.celebration, color: Colors.purple.withOpacity(0.8), size: 30),
          ],
        ),
      ),
    );
  }
}
