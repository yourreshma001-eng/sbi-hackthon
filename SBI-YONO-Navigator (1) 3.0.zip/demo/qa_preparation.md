
# SBI HACKATHON Q&A PREPARATION

## QUESTION 1: How is this different from SBI's existing chatbot?
**ANSWER:**
"SBI's current chatbot is REACTIVE — it waits for customers to ask questions.
Our Navigator is PROACTIVE — it predicts needs before the customer knows.

Chatbot = Librarian (answers questions)
Navigator = Personal Assistant (completes tasks autonomously)

Current flow: Customer asks → Bot suggests → Customer searches → Customer completes
Our flow: AI predicts → Pre-fills everything → One tap → Done"

## QUESTION 2: What about data privacy?
**ANSWER:**
"Three layers of protection:
1. PII never touches cloud LLMs — we use on-prem LLaMA 3 for sensitive data
2. Guardian Agent validates every action against RBI guidelines
3. DPDP Act compliant — explicit consent, immutable audit trail

Every action has SHA-256 hash. Every decision is traceable."

## QUESTION 3: Can this scale to 500M customers?
**ANSWER:**
"Architecture is built for scale:
- Kubernetes-based, horizontally scalable
- Benchmarked at 10,000 TPS (matches SBI's current SIA load)
- 22 Indian languages via Bhashini API (free, government-backed)
- Event-driven architecture with Kafka + Redis

We don't just claim scale — we benchmarked it."

## QUESTION 4: What's the business impact?
**ANSWER:**
"Hard numbers:
- 43 Crore inactive digital customers
- Rs.40-60 cost per branch transaction
- 10% shift to digital = 4.3 Crore customers
- Annual savings: Rs.400+ Crore
- Cross-sell revenue: Rs.200+ Crore
- Total impact: Rs.600+ Crore per year

For SBI, this isn't just innovation — it's survival."

## QUESTION 5: Why should SBI choose you over building in-house?
**ANSWER:**
"Speed. We built this in 14 days. SBI's internal timeline would be 14 months.

SBI's own actions prove this:
- Rs.22 Crore IIT-Bombay partnership for AI
- Chairman explicitly stated: 'Revamping digital for hyper-personalization'
- They WANT external innovation

We bring:
- Proven multi-agent architecture
- Working prototype with 3 scenarios
- Measurable ROI from day one
- Ready to pilot with 1M customers in Q3 2026"

## QUESTION 6: What if the AI makes wrong predictions?
**ANSWER:**
"Guardian Agent has three safeguards:
1. Confidence threshold — below 85%, no action taken
2. Human-in-the-loop — every action requires explicit consent
3. Feedback loop — wrong predictions improve the model

Customer can always say NO. That's built into the design."

## QUESTION 7: How do you handle vernacular languages?
**ANSWER:**
"Bhashini API — Government of India's free API.
- 22 Indian languages
- Text-to-speech with regional accents
- Dialect detection
- No ML expertise needed — just API calls

This isn't just translation. It's cultural adaptation."

## QUESTION 8: What's your tech stack?
**ANSWER:**
"All free, open-source tools:
- Backend: Python + FastAPI
- Agents: Custom multi-agent orchestration
- LLM: Groq API (free tier) + LLaMA 3 (on-prem)
- Voice: Bhashini API (government, free)
- Frontend: Flutter (cross-platform)
- Hosting: Render/Railway (free tier)

Total cost: Rs.0. Impact: Rs.600+ Crore."

## QUESTION 9: What's your go-to-market plan?
**ANSWER:**
"Phase 1: Pilot — 1M customers, Q3 2026
Phase 2: Scale — 50M customers, FY 2027
Phase 3: Full — All 500M customers, FY 2028
Phase 4: Global — SBI International (UK, Canada)

We start small, prove ROI, then scale."

## QUESTION 10: Demo failure — what if live demo crashes?
**ANSWER:**
"We have:
1. Pre-recorded 2-minute demo video (backup)
2. Screenshots of all 3 scenarios
3. Postman API collection for live testing
4. Swagger UI at /docs for interactive testing

Demo won't fail. But if it does, we have 4 backups."
