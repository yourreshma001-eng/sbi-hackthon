
# SBI YONO NAVIGATOR — 2-MINUTE DEMO VIDEO SCRIPT

## OPENING (0:00 - 0:15)
"SBI has 52 Crore customers. But 43 Crore of them never use digital banking. 
That's 83% of India's largest bank still visiting branches for every small task.
Today, I'm going to show you how SBI YONO Navigator changes everything."

## TRANSITION (0:15 - 0:20)
[Screen shows app opening with splash animation]

## SCENARIO 1: RAMESH — QR CASH (0:20 - 0:50)
"Meet Ramesh Kumar from Delhi. Digital Maturity: 25%. He only uses ATM.
Today, Ramesh walks past an SBI ATM. Our Prophet Agent detects this instantly."

[Click TRIGGER AI PREDICTION]

"Prophet predicts: Cash need, 94% confidence. 
Strategist decides: Voice call in Hindi, immediate.
Executor pre-generates QR code.
Guardian validates: KYC PASS, Fraud PASS, Consent PENDING."

[Show Bhasha message in Hindi]

"Ramesh hears: 'Ramesh ji, QR code ready. Scan at ATM, enter PIN, collect cash.'
He taps YES. Done. 10 seconds. No card needed."

[Click TAP TO COMPLETE — show success animation]

"Digital adoption complete. Ramesh earned 2 Digital Stars."

## SCENARIO 2: PRIYA — SIP (0:50 - 1:20)
"Now Priya Sharma from Chennai. Salary just credited. No SIP.
Prophet detects: Investment opportunity."

[Switch to Priya, click TRIGGER]

"Strategist: App notification in Tamil.
Executor: Pre-fills Rs.5,000 SIP in SBI Bluechip Fund.
Guardian: All checks pass."

[Show Tamil message]

"Priya taps YES. SIP starts. Auto-debit every month. 
15 seconds. Zero paperwork."

[Show completion]

## SCENARIO 3: RAJESH — INSURANCE (1:20 - 1:50)
"Rajesh Reddy from Hyderabad. Hospital payment detected 3 days ago.
Prophet: Life event — possible childbirth."

[Switch to Rajesh, click TRIGGER]

"Strategist: Warm voice in Telugu.
Executor: Pre-opens Sukanya Samriddhi account.
Guardian: KYC verified, all compliant."

[Show Telugu message]

"Rajesh taps YES. Daughter's future secured. 8.2% interest locked.
20 seconds. No branch visit."

## CLOSING (1:50 - 2:00)
"Three customers. Three languages. Three digital adoptions. 
One tap each. SBI YONO Navigator — We don't wait for customers to ask. 
We predict what they need. Thank you."

[Show architecture diagram + business impact numbers]
