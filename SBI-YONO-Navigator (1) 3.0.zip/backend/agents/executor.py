
"""
EXECUTOR AGENT - Completes the digital task autonomously
"""
import json
import uuid
from typing import Dict

class ExecutorAgent:
    """
    Pre-fills forms, generates QR codes, opens accounts, sets up auto-pay.
    Completes 80% of the task before customer sees it.
    """

    def __init__(self):
        self.completed_tasks = []

    def execute(self, plan: Dict, customer_profile: Dict) -> Dict:
        """
        Executes the planned action and returns completion status
        """
        task_id = str(uuid.uuid4())
        result = {
            "task_id": task_id,
            "customer_id": plan["customer_id"],
            "plan_id": plan["plan_id"],
            "status": "prepared",  # prepared → pending_consent → completed
            "timestamp": "2026-06-21T10:48:30Z"
        }

        action_type = plan.get("prediction_type", "")

        if action_type == "cash_need":
            # Pre-generate QR code for ATM withdrawal
            result["action"] = "qr_cash_withdrawal"
            result["pre_generated"] = {
                "qr_code": f"SBI_QR_{task_id[:8]}",
                "amount_suggested": 10000,
                "atm_location": "SBI ATM - Connaught Place, Delhi",
                "valid_until": "2026-06-21T12:48:30Z",
                "instructions": "Scan QR at ATM, enter PIN, collect cash"
            }
            result["customer_message"] = {
                "hindi": "रमेश जी, आप ATM के पास हैं। QR कोड तैयार है। ATM पर scan करें, PIN डालें, पैसे लें। कोई card नहीं चाहिए।",
                "english": "Ramesh ji, you're near the ATM. QR code is ready. Scan at ATM, enter PIN, collect cash. No card needed."
            }

        elif action_type == "investment_opportunity":
            # Pre-fill SIP form
            suggested_amount = plan.get("suggested_amount", 2000)
            result["action"] = "sip_setup"
            result["pre_generated"] = {
                "fund_name": "SBI Bluechip Fund",
                "sip_amount": suggested_amount,
                "frequency": "monthly",
                "debit_date": "5th of every month",
                "first_installment": "2026-07-05",
                "pre_filled_form": True,
                "kyc_status": "verified"  # Guardian checks this
            }
            result["customer_message"] = {
                "hindi": f"रमेश जी, आपके खाते में सैलरी आई है। क्या हर महीने ₹{suggested_amount} SIP शुरू करें? एक tap में done।",
                "english": f"Ramesh ji, salary credited. Start ₹{suggested_amount} monthly SIP? One tap to complete."
            }

        elif action_type == "life_event_insurance":
            # Pre-fill Sukanya Samriddhi account opening
            result["action"] = "sukanya_account_open"
            result["pre_generated"] = {
                "scheme": "Sukanya Samriddhi Yojana",
                "child_name": "Daughter of Ramesh Kumar",  # Would be fetched from KYC
                "initial_deposit": 1000,
                "account_number": f"SSY_{task_id[:8]}",
                "interest_rate": "8.2%",
                "maturity": "21 years",
                "pre_filled_form": True
            }
            result["customer_message"] = {
                "hindi": "रमेश जी, बधाई हो! आपकी बेटी के लिए Sukanya Samriddhi Yojana खोलें? ₹1000 से शुरू, 8.2% ब्याज। एक tap में account खुला।",
                "english": "Congratulations Ramesh ji! Open Sukanya Samriddhi for your daughter? Start with ₹1000, 8.2% interest. One tap to open."
            }

        result["requires_tap"] = True  # Customer just taps "Yes"
        result["tap_expires"] = "2026-06-21T11:48:30Z"  # 1 hour validity

        self.completed_tasks.append(result)
        return result


# Demo
if __name__ == "__main__":
    plan = {
        "prediction_type": "cash_need",
        "customer_id": "CUST001",
        "plan_id": "PLAN_CUST001_cash_need",
        "language": "hindi"
    }

    customer_profile = {
        "name": "Ramesh Kumar",
        "phone": "+91-98765-43210"
    }

    executor = ExecutorAgent()
    result = executor.execute(plan, customer_profile)

    print("=" * 50)
    print("🤖 EXECUTOR AGENT RESULT")
    print("=" * 50)
    print(json.dumps(result, indent=2))
