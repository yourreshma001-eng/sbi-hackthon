
"""
BHASHA AGENT - Vernacular Voice & Communication
"""
import json
from typing import Dict

class BhashaAgent:
    """
    Communicates with customer in their preferred language.
    Uses Bhashini API (free, Government of India) for 22 Indian languages.
    Fallback: Pre-recorded message templates.
    """

    def __init__(self):
        self.supported_languages = [
            "hindi", "tamil", "telugu", "bengali", "marathi",
            "gujarati", "kannada", "malayalam", "punjabi", "odia"
        ]

        # Message templates for demo (no API needed for hackathon)
        self.message_templates = {
            "qr_cash_adoption": {
                "hindi": "{name} जी, आप ATM के पास हैं। QR कोड तैयार है। ATM पर scan करें, PIN डालें, पैसे लें। कोई card नहीं चाहिए।",
                "english": "{name}, you're near the ATM. QR code is ready. Scan at ATM, enter PIN, collect cash. No card needed.",
                "tamil": "{name} அவர்களே, நீங்கள் ATM அருகில் உள்ளீர்கள். QR குறியீடு தயாராக உள்ளது. ATM-இல் scan செய்யுங்கள்.",
                "telugu": "{name} గారు, మీరు ATM దగ్గర ఉన్నారు. QR కోడ్ సిద్ధంగా ఉంది. ATM వద్ద scan చేయండి."
            },
            "sip_suggestion": {
                "hindi": "{name} जी, आपके खाते में सैलरी आई है। क्या हर महीने ₹{amount} SIP शुरू करें? एक tap में done।",
                "english": "{name}, salary credited. Start ₹{amount} monthly SIP? One tap to complete.",
                "tamil": "{name} அவர்களே, சம்பளம் வந்துவிட்டது. மாதம் ₹{amount} SIP தொடங்கவா? ஒரு tap-இல் முடிந்தது.",
                "telugu": "{name} గారు, జీతం వచ్చింది. ప్రతి నెల ₹{amount} SIP ప్రారంభించాలా? ఒక tap తో పూర్తి."
            },
            "child_savings_congratulations": {
                "hindi": "{name} जी, बधाई हो! आपकी बेटी के लिए Sukanya Samriddhi Yojana खोलें? ₹{amount} से शुरू, 8.2% ब्याज। एक tap में account खुला।",
                "english": "Congratulations {name}! Open Sukanya Samriddhi for your daughter? Start with ₹{amount}, 8.2% interest. One tap to open.",
                "tamil": "{name} அவர்களே, வாழ்த்துக்கள்! உங்கள் மகளுக்கு Sukanya Samriddhi திட்டம் தொடங்கவா? ₹{amount} முதல், 8.2% வட்டி.",
                "telugu": "{name} గారు, అభినందనలు! మీ కూతురి కోసం Sukanya Samriddhi తెరవాలా? ₹{amount} నుండి, 8.2% వడ్డీ."
            }
        }

    def generate_message(self, template_key: str, language: str, **kwargs) -> Dict:
        """
        Generates vernacular message from template
        """
        template = self.message_templates.get(template_key, {}).get(language, "")
        if not template:
            template = self.message_templates.get(template_key, {}).get("english", "")

        message = template.format(**kwargs)

        return {
            "language": language,
            "message": message,
            "template": template_key,
            "voice_url": None,  # Would be Bhashini TTS URL in production
            "text_ready": True,
            "voice_ready": False  # For hackathon, text is sufficient
        }

    def call_bhashini_tts(self, text: str, language: str) -> str:
        """
        Calls Bhashini API for text-to-speech
        (For production - hackathon demo uses text only)
        """
        # Production code:
        # import requests
        # url = "https://tts.bhashini.ai/v1/synthesize"
        # response = requests.post(url, json={
        #     "text": text,
        #     "language": language,
        #     "voice": "female"
        # })
        # return response.json()["audio_url"]

        return f"https://bhashini.example/audio/{language}/{hash(text) % 10000}"


# Demo
if __name__ == "__main__":
    bhasha = BhashaAgent()

    result = bhasha.generate_message(
        template_key="qr_cash_adoption",
        language="hindi",
        name="Ramesh"
    )

    print("=" * 50)
    print("🗣️ BHASHA AGENT MESSAGE")
    print("=" * 50)
    print(json.dumps(result, indent=2, ensure_ascii=False))
