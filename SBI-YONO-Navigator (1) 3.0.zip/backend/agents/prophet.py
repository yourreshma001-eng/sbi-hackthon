
"""
PROPHET AGENT - Predicts customer needs before they know it
"""
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class ProphetAgent:
    """
    Analyzes customer transaction patterns, location, and life events
    to predict next financial need with confidence score.
    """

    def __init__(self, customer_id: str):
        self.customer_id = customer_id
        self.transactions = self._load_transactions()
        self.digital_maturity = self._calculate_digital_maturity()

    def _load_transactions(self) -> List[Dict]:
        """Load customer-specific mock transaction data for demo"""
        today = datetime.now()

        customer_data = {
            "CUST001": [  # Ramesh - ATM heavy, no digital, hospital payment
                {"date": (today - timedelta(days=20)).strftime("%Y-%m-%d"), "type": "credit", "amount": 50000, "description": "Salary", "balance": 75000},
                {"date": (today - timedelta(days=18)).strftime("%Y-%m-%d"), "type": "debit", "amount": 15000, "description": "ATM Withdrawal", "balance": 60000},
                {"date": (today - timedelta(days=16)).strftime("%Y-%m-%d"), "type": "debit", "amount": 8000, "description": "Grocery", "balance": 52000},
                {"date": (today - timedelta(days=14)).strftime("%Y-%m-%d"), "type": "debit", "amount": 12000, "description": "ATM Withdrawal", "balance": 40000},
                {"date": (today - timedelta(days=11)).strftime("%Y-%m-%d"), "type": "debit", "amount": 5000, "description": "Utility Bill", "balance": 35000},
                {"date": (today - timedelta(days=6)).strftime("%Y-%m-%d"), "type": "credit", "amount": 50000, "description": "Salary", "balance": 85000},
                {"date": (today - timedelta(days=4)).strftime("%Y-%m-%d"), "type": "debit", "amount": 20000, "description": "ATM Withdrawal", "balance": 65000},
                {"date": (today - timedelta(days=3)).strftime("%Y-%m-%d"), "type": "debit", "amount": 10000, "description": "Hospital Payment", "balance": 55000},
                {"date": (today - timedelta(days=1)).strftime("%Y-%m-%d"), "type": "debit", "amount": 5000, "description": "ATM Withdrawal", "balance": 50000},
            ],
            "CUST002": [  # Priya - Salary, no SIP, some digital
                {"date": (today - timedelta(days=20)).strftime("%Y-%m-%d"), "type": "credit", "amount": 60000, "description": "Salary", "balance": 85000},
                {"date": (today - timedelta(days=16)).strftime("%Y-%m-%d"), "type": "debit", "amount": 20000, "description": "Rent", "balance": 65000},
                {"date": (today - timedelta(days=13)).strftime("%Y-%m-%d"), "type": "debit", "amount": 5000, "description": "UPI Payment", "balance": 60000},
                {"date": (today - timedelta(days=11)).strftime("%Y-%m-%d"), "type": "debit", "amount": 15000, "description": "Shopping", "balance": 45000},
                {"date": (today - timedelta(days=9)).strftime("%Y-%m-%d"), "type": "debit", "amount": 3000, "description": "Online Transfer", "balance": 42000},
                {"date": (today - timedelta(days=6)).strftime("%Y-%m-%d"), "type": "credit", "amount": 60000, "description": "Salary", "balance": 102000},
                {"date": (today - timedelta(days=3)).strftime("%Y-%m-%d"), "type": "debit", "amount": 10000, "description": "ATM Withdrawal", "balance": 92000},
                {"date": (today - timedelta(days=2)).strftime("%Y-%m-%d"), "type": "debit", "amount": 8000, "description": "Grocery", "balance": 84000},
                {"date": (today - timedelta(days=1)).strftime("%Y-%m-%d"), "type": "debit", "amount": 4000, "description": "UPI Payment", "balance": 80000},
            ],
            "CUST003": [  # Rajesh - Hospital payment, some digital
                {"date": (today - timedelta(days=20)).strftime("%Y-%m-%d"), "type": "credit", "amount": 100000, "description": "Salary", "balance": 150000},
                {"date": (today - timedelta(days=16)).strftime("%Y-%m-%d"), "type": "debit", "amount": 30000, "description": "Home Loan EMI", "balance": 120000},
                {"date": (today - timedelta(days=13)).strftime("%Y-%m-%d"), "type": "debit", "amount": 5000, "description": "UPI Payment", "balance": 115000},
                {"date": (today - timedelta(days=11)).strftime("%Y-%m-%d"), "type": "debit", "amount": 25000, "description": "Hospital Payment", "balance": 90000},
                {"date": (today - timedelta(days=9)).strftime("%Y-%m-%d"), "type": "debit", "amount": 10000, "description": "Online Transfer", "balance": 80000},
                {"date": (today - timedelta(days=6)).strftime("%Y-%m-%d"), "type": "credit", "amount": 100000, "description": "Salary", "balance": 180000},
                {"date": (today - timedelta(days=3)).strftime("%Y-%m-%d"), "type": "debit", "amount": 15000, "description": "School Fees", "balance": 165000},
                {"date": (today - timedelta(days=2)).strftime("%Y-%m-%d"), "type": "debit", "amount": 8000, "description": "UPI Payment", "balance": 157000},
                {"date": (today - timedelta(days=1)).strftime("%Y-%m-%d"), "type": "debit", "amount": 12000, "description": "Grocery", "balance": 145000},
            ]
        }
        return customer_data.get(self.customer_id, customer_data["CUST001"])

    def _calculate_digital_maturity(self) -> float:
        """Score 0-1: how digitally active is customer"""
        digital_txns = sum(1 for t in self.transactions if t["description"] in ["UPI Payment", "Online Transfer", "SIP"])
        total = len(self.transactions)
        return min(digital_txns / total + 0.2, 1.0) if total > 0 else 0.2

    def predict(self, current_location: Optional[str] = None) -> Dict:
        """
        Main prediction engine
        Returns: prediction with confidence, type, and recommended action
        """
        predictions = []

        # PRIORITY 1: ATM proximity + cash withdrawal pattern (HIGHEST URGENCY)
        atm_withdrawals = [t for t in self.transactions if "ATM" in t["description"]]
        avg_withdrawal = sum(t["amount"] for t in atm_withdrawals) / len(atm_withdrawals) if atm_withdrawals else 0
        last_withdrawal_days = (datetime.now() - datetime.strptime(atm_withdrawals[-1]["date"], "%Y-%m-%d")).days if atm_withdrawals else 999

        if current_location and "ATM" in current_location:
            # ATM proximity is highest priority - return immediately
            return {
                "type": "cash_need",
                "confidence": 0.94,
                "timeframe": "next_2_hours",
                "recommended_action": "upi_qr_adoption",
                "reason": f"Customer near ATM, last withdrawal {last_withdrawal_days} days ago, avg ₹{avg_withdrawal:.0f}",
                "urgency": "high",
                "digital_maturity_score": self.digital_maturity,
                "customer_id": self.customer_id
            }

        # PRIORITY 2: Salary credited + no SIP
        salary_txns = [t for t in self.transactions if "Salary" in t["description"]]
        sip_txns = [t for t in self.transactions if "SIP" in t["description"]]

        if salary_txns and not sip_txns:
            last_salary = datetime.strptime(salary_txns[-1]["date"], "%Y-%m-%d")
            days_since_salary = (datetime.now() - last_salary).days
            if days_since_salary <= 7:
                predictions.append({
                    "type": "investment_opportunity",
                    "confidence": 0.91,
                    "timeframe": "next_48_hours",
                    "recommended_action": "auto_invest_sip",
                    "reason": f"Salary credited {days_since_salary} days ago, no SIP found, balance ₹{self.transactions[-1]['balance']}",
                    "urgency": "medium"
                })

        # PRIORITY 3: Life event - hospital payment
        hospital_txns = [t for t in self.transactions if "Hospital" in t["description"]]
        if hospital_txns:
            last_hospital = datetime.strptime(hospital_txns[-1]["date"], "%Y-%m-%d")
            days_since = (datetime.now() - last_hospital).days
            if days_since <= 14:
                predictions.append({
                    "type": "life_event_insurance",
                    "confidence": 0.88,
                    "timeframe": "next_7_days",
                    "recommended_action": "sukanya_samriddhi",
                    "reason": f"Hospital payment {days_since} days ago - possible childbirth, suggest child savings scheme",
                    "urgency": "medium"
                })

        # Return highest confidence prediction
        if predictions:
            best = max(predictions, key=lambda x: x["confidence"])
            best["digital_maturity_score"] = self.digital_maturity
            best["customer_id"] = self.customer_id
            return best

        return {
            "type": "no_prediction",
            "confidence": 0.0,
            "digital_maturity_score": self.digital_maturity,
            "customer_id": self.customer_id
        }


# Demo
if __name__ == "__main__":
    agent = ProphetAgent("CUST001")
    prediction = agent.predict(current_location="near_SBI_ATM")
    print("=" * 50)
    print("🔮 PROPHET AGENT PREDICTION")
    print("=" * 50)
    print(json.dumps(prediction, indent=2))
