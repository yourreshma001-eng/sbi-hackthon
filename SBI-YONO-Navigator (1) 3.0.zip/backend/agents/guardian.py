
"""
GUARDIAN AGENT - Security, Compliance, and Trust
"""
import json
import hashlib
from datetime import datetime
from typing import Dict

class GuardianAgent:
    """
    Validates every action against RBI guidelines, fraud patterns, and consent.
    Generates immutable audit trail for compliance.
    """

    def __init__(self):
        self.audit_log = []
        self.rbi_guidelines = {
            "max_daily_withdrawal": 100000,
            "min_kyc_for_investment": True,
            "consent_required_for": ["investment", "account_opening", "auto_debit", "qr_cash_withdrawal", "sip_setup", "sukanya_account_open"],
            "fraud_threshold": 0.7
        }

    def validate(self, execution_result: Dict, customer_profile: Dict) -> Dict:
        """
        Validates execution plan and returns approval/rejection
        """
        task_id = execution_result["task_id"]
        action = execution_result["action"]

        validation = {
            "task_id": task_id,
            "timestamp": datetime.now().isoformat(),
            "checks": {},
            "approved": False,
            "reasons": []
        }

        # Check 1: KYC Verification
        kyc_verified = customer_profile.get("kyc_status", "verified") == "verified"
        validation["checks"]["kyc"] = {
            "status": "PASS" if kyc_verified else "FAIL",
            "detail": "KYC verified" if kyc_verified else "KYC pending - reject"
        }
        if not kyc_verified:
            validation["reasons"].append("KYC not verified")

        # Check 2: Fraud Pattern Detection
        fraud_score = self._check_fraud_patterns(execution_result, customer_profile)
        validation["checks"]["fraud"] = {
            "status": "PASS" if fraud_score < self.rbi_guidelines["fraud_threshold"] else "FAIL",
            "fraud_score": fraud_score,
            "detail": "No fraud detected" if fraud_score < 0.7 else "Fraud risk detected"
        }
        if fraud_score >= self.rbi_guidelines["fraud_threshold"]:
            validation["reasons"].append("Fraud risk detected")

        # Check 3: Consent Validation
        consent_required = action in self.rbi_guidelines["consent_required_for"]
        if consent_required:
            validation["checks"]["consent"] = {
                "status": "PENDING",
                "detail": "Explicit customer consent required before execution",
                "consent_type": "one_tap_approval"
            }
        else:
            validation["checks"]["consent"] = {
                "status": "NOT_REQUIRED",
                "detail": "Low risk action - consent implicit"
            }

        # Check 4: Amount Limits (for investments/withdrawals)
        if "amount" in str(execution_result) or "sip_amount" in str(execution_result):
            amount = execution_result.get("pre_generated", {}).get("sip_amount", 0)
            validation["checks"]["amount_limit"] = {
                "status": "PASS" if amount <= 50000 else "REVIEW",
                "amount": amount,
                "detail": "Within limits" if amount <= 50000 else "Requires manual review"
            }

        # Final Decision
        all_pass = all(
            check["status"] in ["PASS", "NOT_REQUIRED", "PENDING"] 
            for check in validation["checks"].values()
        )

        if all_pass and not validation["reasons"]:
            validation["approved"] = True
            validation["status"] = "APPROVED_PENDING_CONSENT" if consent_required else "APPROVED_AUTO"
        else:
            validation["approved"] = False
            validation["status"] = "REJECTED"

        # Generate audit hash (immutable record)
        audit_string = json.dumps(validation, sort_keys=True)
        validation["audit_hash"] = hashlib.sha256(audit_string.encode()).hexdigest()[:16]

        self.audit_log.append(validation)
        return validation

    def _check_fraud_patterns(self, execution_result: Dict, customer_profile: Dict) -> float:
        """
        Simple fraud detection (0-1 score, higher = more suspicious)
        """
        score = 0.0

        # Unusual location
        if customer_profile.get("last_location", "Delhi") != "Delhi":
            score += 0.2

        # Rapid successive transactions
        if len(self.audit_log) > 5:
            score += 0.1

        # High amount
        amount = execution_result.get("pre_generated", {}).get("sip_amount", 0)
        if amount > 25000:
            score += 0.2

        return min(score, 0.99)

    def get_audit_trail(self, customer_id: str) -> list:
        """Returns all audit records for a customer"""
        return [log for log in self.audit_log if log.get("customer_id") == customer_id]


# Demo
if __name__ == "__main__":
    execution_result = {
        "task_id": "TASK_123",
        "action": "sip_setup",
        "pre_generated": {"sip_amount": 2000}
    }

    customer_profile = {
        "name": "Ramesh Kumar",
        "kyc_status": "verified",
        "last_location": "Delhi"
    }

    guardian = GuardianAgent()
    validation = guardian.validate(execution_result, customer_profile)

    print("=" * 50)
    print("🛡️ GUARDIAN AGENT VALIDATION")
    print("=" * 50)
    print(json.dumps(validation, indent=2))
