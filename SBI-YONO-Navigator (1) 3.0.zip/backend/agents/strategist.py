
"""
STRATEGIST AGENT - Decides HOW to engage the customer
"""
import json
from typing import Dict

class StrategistAgent:
    """
    Takes Prophet's prediction and creates the optimal engagement plan:
    - Which channel (SMS, App, Voice Call)
    - What timing
    - What offer/incentive
    - What language
    """

    def __init__(self, customer_profile: Dict):
        self.profile = customer_profile

    def create_plan(self, prediction: Dict) -> Dict:
        """
        Creates engagement strategy based on prediction and customer profile
        """
        plan = {
            "prediction_type": prediction["type"],
            "confidence": prediction["confidence"],
            "customer_id": prediction["customer_id"],
            "digital_maturity": prediction["digital_maturity_score"],
            "plan_id": f"PLAN_{prediction['customer_id']}_{prediction['type']}",
            "timestamp": "2026-06-21T10:48:00Z"
        }

        # Channel selection based on urgency and digital maturity
        if prediction["urgency"] == "high":
            plan["channel"] = "voice_call"  # Most attention-grabbing
            plan["timing"] = "immediate"
        elif prediction["digital_maturity_score"] < 0.3:
            plan["channel"] = "voice_call"  # Non-digital users need voice
            plan["timing"] = "evening_6pm"  # When they're free
        else:
            plan["channel"] = "app_notification"
            plan["timing"] = "immediate"

        # Language selection
        plan["language"] = self.profile.get("preferred_language", "hindi")

        # Offer/personalization
        if prediction["type"] == "cash_need":
            plan["offer"] = "first_qr_free"  # No charges first time
            plan["message_template"] = "qr_cash_adoption"
            plan["pre_fill"] = True  # Executor pre-generates QR
            plan["guardian_check"] = "low_risk"

        elif prediction["type"] == "investment_opportunity":
            plan["offer"] = "zero_sip_charges_3months"
            plan["message_template"] = "sip_suggestion"
            plan["pre_fill"] = True  # Pre-fill SIP form
            plan["guardian_check"] = "medium_risk"
            plan["suggested_amount"] = min(5000, int(prediction.get("balance", 50000) * 0.1))

        elif prediction["type"] == "life_event_insurance":
            plan["offer"] = "sukanya_bonus_500"
            plan["message_template"] = "child_savings_congratulations"
            plan["pre_fill"] = True
            plan["guardian_check"] = "medium_risk"
            plan["emotional_tone"] = "warm_celebratory"

        # Guardian approval requirements
        plan["requires_consent"] = True
        plan["audit_level"] = "detailed"

        return plan


# Demo
if __name__ == "__main__":
    customer_profile = {
        "name": "Ramesh Kumar",
        "age": 35,
        "preferred_language": "hindi",
        "location": "Delhi",
        "phone": "+91-98765-43210"
    }

    prediction = {
        "type": "cash_need",
        "confidence": 0.94,
        "customer_id": "CUST001",
        "digital_maturity_score": 0.25,
        "timeframe": "next_2_hours",
        "recommended_action": "upi_qr_adoption",
        "reason": "Customer near ATM, last withdrawal 3 days ago",
        "urgency": "high"
    }

    strategist = StrategistAgent(customer_profile)
    plan = strategist.create_plan(prediction)

    print("=" * 50)
    print("🧠 STRATEGIST AGENT PLAN")
    print("=" * 50)
    print(json.dumps(plan, indent=2))
