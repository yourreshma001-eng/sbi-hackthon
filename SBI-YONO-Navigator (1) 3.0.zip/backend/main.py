
"""
SBI YONO NAVIGATOR - Main API Server
Orchestrates all 5 agents for the hackathon demo
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict
import json
import uuid
from datetime import datetime

# Import agents
from agents.prophet import ProphetAgent
from agents.strategist import StrategistAgent
from agents.executor import ExecutorAgent
from agents.guardian import GuardianAgent
from agents.bhasha import BhashaAgent

app = FastAPI(
    title="SBI YONO Navigator",
    description="Autonomous Digital Adoption AI for SBI",
    version="1.0.0"
)

# CORS for Flutter frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class CustomerRequest(BaseModel):
    customer_id: str
    current_location: Optional[str] = None

class ConsentRequest(BaseModel):
    task_id: str
    customer_id: str
    approved: bool

# Mock customer database
CUSTOMERS = {
    "CUST001": {
        "name": "Ramesh Kumar",
        "age": 35,
        "preferred_language": "hindi",
        "location": "Delhi",
        "phone": "+91-98765-43210",
        "kyc_status": "verified",
        "account_balance": 50000
    },
    "CUST002": {
        "name": "Priya Sharma",
        "age": 28,
        "preferred_language": "tamil",
        "location": "Chennai",
        "phone": "+91-98765-43211",
        "kyc_status": "verified",
        "account_balance": 75000
    },
    "CUST003": {
        "name": "Rajesh Reddy",
        "age": 42,
        "preferred_language": "telugu",
        "location": "Hyderabad",
        "phone": "+91-98765-43212",
        "kyc_status": "verified",
        "account_balance": 120000
    }
}

# Store active predictions
active_predictions = {}

@app.get("/")
def root():
    return {
        "message": "SBI YONO Navigator API",
        "version": "1.0.0",
        "status": "active",
        "agents": ["Prophet", "Strategist", "Executor", "Guardian", "Bhasha"]
    }

@app.get("/api/customers/{customer_id}")
def get_customer(customer_id: str):
    if customer_id not in CUSTOMERS:
        raise HTTPException(status_code=404, detail="Customer not found")
    return CUSTOMERS[customer_id]

@app.post("/api/predict")
def predict_need(request: CustomerRequest):
    """
    Full agent pipeline: Prophet -> Strategist -> Executor -> Guardian -> Bhasha
    """
    customer_id = request.customer_id

    if customer_id not in CUSTOMERS:
        raise HTTPException(status_code=404, detail="Customer not found")

    customer = CUSTOMERS[customer_id]

    # Step 1: PROPHET - Predict need
    prophet = ProphetAgent(customer_id)
    prediction = prophet.predict(current_location=request.current_location)

    if prediction["type"] == "no_prediction":
        return {
            "status": "no_action",
            "message": "No prediction available for this customer"
        }

    # Step 2: STRATEGIST - Create plan
    strategist = StrategistAgent(customer)
    plan = strategist.create_plan(prediction)

    # Step 3: EXECUTOR - Prepare action
    executor = ExecutorAgent()
    execution = executor.execute(plan, customer)

    # Step 4: GUARDIAN - Validate
    guardian = GuardianAgent()
    validation = guardian.validate(execution, customer)

    # Step 5: BHASHA - Generate message
    bhasha = BhashaAgent()
    message = bhasha.generate_message(
        template_key=plan.get("message_template", "qr_cash_adoption"),
        language=customer["preferred_language"],
        name=customer["name"].split()[0],
        amount=execution.get("pre_generated", {}).get("sip_amount", 2000)
    )

    # Store for consent
    task_id = execution["task_id"]
    active_predictions[task_id] = {
        "execution": execution,
        "plan": plan,
        "customer": customer,
        "validation": validation
    }

    return {
        "status": "prediction_ready",
        "task_id": task_id,
        "customer": {
            "name": customer["name"],
            "language": customer["preferred_language"]
        },
        "prediction": {
            "type": prediction["type"],
            "confidence": prediction["confidence"],
            "reason": prediction["reason"]
        },
        "action": {
            "type": execution["action"],
            "pre_generated": execution["pre_generated"],
            "requires_tap": execution["requires_tap"],
            "tap_expires": execution["tap_expires"]
        },
        "message": message,
        "security": {
            "guardian_status": validation["status"],
            "audit_hash": validation["audit_hash"],
            "checks": validation["checks"]
        },
        "digital_maturity": prediction["digital_maturity_score"]
    }

@app.post("/api/consent")
def give_consent(request: ConsentRequest):
    """
    Customer taps "Yes" - complete the action
    """
    task_id = request.task_id

    if task_id not in active_predictions:
        raise HTTPException(status_code=404, detail="Task not found or expired")

    if not request.approved:
        return {
            "status": "cancelled",
            "task_id": task_id,
            "message": "Action cancelled by customer"
        }

    task = active_predictions[task_id]

    # Complete the action
    action_type = task["execution"]["action"]

    if action_type == "qr_cash_withdrawal":
        result = {
            "status": "completed",
            "task_id": task_id,
            "action": "QR Cash Withdrawal enabled",
            "details": {
                "qr_code": task["execution"]["pre_generated"]["qr_code"],
                "valid_until": task["execution"]["pre_generated"]["valid_until"],
                "instructions": "Scan QR at ATM, enter PIN, collect cash"
            },
            "next_steps": "Go to ATM, open YONO app, scan QR, enter PIN"
        }
    elif action_type == "sip_setup":
        result = {
            "status": "completed",
            "task_id": task_id,
            "action": "SIP Started",
            "details": {
                "fund": task["execution"]["pre_generated"]["fund_name"],
                "amount": task["execution"]["pre_generated"]["sip_amount"],
                "frequency": task["execution"]["pre_generated"]["frequency"],
                "first_debit": task["execution"]["pre_generated"]["first_installment"]
            },
            "next_steps": "SIP will auto-debit on 5th of every month"
        }
    elif action_type == "sukanya_account_open":
        result = {
            "status": "completed",
            "task_id": task_id,
            "action": "Sukanya Samriddhi Account Opened",
            "details": {
                "account_number": task["execution"]["pre_generated"]["account_number"],
                "initial_deposit": task["execution"]["pre_generated"]["initial_deposit"],
                "interest_rate": task["execution"]["pre_generated"]["interest_rate"],
                "maturity": task["execution"]["pre_generated"]["maturity"]
            },
            "next_steps": "Deposit ₹1000 to activate, then monthly deposits"
        }

    # Update digital maturity
    result["digital_maturity_boost"] = 0.15
    result["digital_stars_earned"] = 2

    return result

@app.get("/api/demo/scenarios")
def get_demo_scenarios():
    """Returns all 3 demo scenarios for testing"""
    return {
        "scenarios": [
            {
                "id": 1,
                "name": "QR Cash Withdrawal",
                "customer_id": "CUST001",
                "trigger": "Customer near ATM + cash withdrawal pattern",
                "location": "near_SBI_ATM",
                "language": "hindi"
            },
            {
                "id": 2,
                "name": "Auto-Invest on Salary Day",
                "customer_id": "CUST002",
                "trigger": "Salary credited + no SIP",
                "location": None,
                "language": "tamil"
            },
            {
                "id": 3,
                "name": "Insurance on Life Event",
                "customer_id": "CUST003",
                "trigger": "Hospital payment detected",
                "location": None,
                "language": "telugu"
            }
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
